﻿ฟอนนี้นี้ฟรี่ 100% สามารถในเชิงพาณิชย์ได้
แต่ถ้าต้องการฟอนต์ตัวเต็ม
สามารถซื้อฟอนต์ได้ตามลิงค์ด้านล้างนี้
-------------------------------------------------
Font free 100% 
If you want full set of font
you can purchase a license 
and full set of font at link below.
-------------------------------------------------
Purchase : https://www.jipatype.com/serithai
My Store : https://www.jipatype.com/
-------------------------------------------------
Contact : anupapjaichumnan@gmail.com
Donate : https://www.paypal.me/akeanupap